const starsCanvas = document.getElementById('stars');
const ctx = starsCanvas.getContext('2d');
let stars = [];
let petals = [];
let w = 0;
let h = 0;

function resizeCanvas() {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  w = window.innerWidth;
  h = window.innerHeight;
  starsCanvas.width = Math.floor(w * dpr);
  starsCanvas.height = Math.floor(h * dpr);
  starsCanvas.style.width = `${w}px`;
  starsCanvas.style.height = `${h}px`;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  stars = Array.from({ length: Math.min(160, Math.floor(w * h / 9000)) }, () => ({
    x: Math.random() * w,
    y: Math.random() * h,
    r: Math.random() * 1.3 + .25,
    a: Math.random() * .7 + .2,
    s: Math.random() * .015 + .004
  }));
  petals = Array.from({ length: Math.min(20, Math.floor(w / 45)) }, () => makePetal(true));
}

function makePetal(initial = false) {
  return {
    x: Math.random() * w,
    y: initial ? Math.random() * h : -30,
    size: Math.random() * 8 + 4,
    speed: Math.random() * .45 + .18,
    drift: Math.random() * .5 - .25,
    rot: Math.random() * Math.PI,
    rotSpeed: Math.random() * .012 - .006,
    alpha: Math.random() * .42 + .18
  };
}

function animateSky() {
  ctx.clearRect(0, 0, w, h);
  for (const star of stars) {
    star.a += star.s;
    if (star.a > .95 || star.a < .18) star.s *= -1;
    ctx.beginPath();
    ctx.arc(star.x, star.y, star.r, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(255, 231, 166, ${star.a})`;
    ctx.fill();
  }
  for (let i = 0; i < petals.length; i++) {
    const p = petals[i];
    p.y += p.speed;
    p.x += Math.sin(p.y * .015) * .18 + p.drift;
    p.rot += p.rotSpeed;
    if (p.y > h + 40 || p.x < -50 || p.x > w + 50) petals[i] = makePetal(false);
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.rotate(p.rot);
    ctx.scale(1, .55);
    ctx.beginPath();
    ctx.ellipse(0, 0, p.size, p.size * .55, 0, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(255, 194, 32, ${p.alpha})`;
    ctx.fill();
    ctx.restore();
  }
  requestAnimationFrame(animateSky);
}

resizeCanvas();
animateSky();
window.addEventListener('resize', resizeCanvas, { passive: true });

const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: .12 });

document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

const sections = [...document.querySelectorAll('main section[id]')];
const navLinks = [...document.querySelectorAll('.nav-link')];
const topbar = document.getElementById('topbar');

window.addEventListener('scroll', () => {
  topbar.classList.toggle('scrolled', window.scrollY > 30);
  let active = 'inicio';
  for (const section of sections) {
    if (window.scrollY >= section.offsetTop - 180) active = section.id;
  }
  navLinks.forEach(link => link.classList.toggle('active', link.getAttribute('href') === `#${active}`));
}, { passive: true });

const lightbox = document.getElementById('lightbox');
const lightboxImage = document.getElementById('lightboxImage');
const lightboxClose = document.getElementById('lightboxClose');

document.querySelectorAll('.photo-card').forEach(card => {
  card.addEventListener('click', () => {
    lightboxImage.src = card.dataset.photo;
    lightbox.classList.add('open');
    lightbox.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  });
});

function closeLightbox() {
  lightbox.classList.remove('open');
  lightbox.setAttribute('aria-hidden', 'true');
  document.body.style.overflow = '';
}
lightboxClose.addEventListener('click', closeLightbox);
lightbox.addEventListener('click', (e) => { if (e.target === lightbox) closeLightbox(); });
window.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeLightbox(); });

const openSurprise = document.getElementById('openSurprise');
const bouquetCard = document.getElementById('bouquetCard');
const secretNote = document.getElementById('secretNote');
openSurprise.addEventListener('click', () => {
  bouquetCard.classList.add('open');
  secretNote.classList.add('show');
  openSurprise.textContent = 'Sorpresa abierta ♥';
  showToast('Para ti, More ✨');
  burstPetals();
});

function burstPetals() {
  for (let i = 0; i < 28; i++) {
    petals.push({
      x: w / 2 + (Math.random() - .5) * Math.min(w * .8, 680),
      y: h * .25 + Math.random() * 130,
      size: Math.random() * 10 + 5,
      speed: Math.random() * 1.1 + .4,
      drift: Math.random() * 1.4 - .7,
      rot: Math.random() * Math.PI,
      rotSpeed: Math.random() * .04 - .02,
      alpha: Math.random() * .5 + .35
    });
  }
}

const bgm = document.getElementById('bgm');
const musicControl = document.getElementById('musicControl');
const playFromCard = document.getElementById('playFromCard');
const toast = document.getElementById('toast');
let toastTimer;

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 3000);
}

async function toggleMusic() {
  if (!bgm.currentSrc || bgm.networkState === HTMLMediaElement.NETWORK_NO_SOURCE) {
    showToast('No se encontró el audio en audio/mi-cancion.mp3.');
    return false;
  }
  try {
    if (bgm.paused) {
      await bgm.play();
      musicControl.classList.add('playing');
      musicControl.setAttribute('aria-label', 'Pausar música');
      showToast('Música activada');
    } else {
      bgm.pause();
      musicControl.classList.remove('playing');
      musicControl.setAttribute('aria-label', 'Activar música');
      showToast('Música pausada');
    }
    return true;
  } catch (error) {
    showToast('Tu navegador bloqueó el audio automático. Toca la nota musical para activarlo.');
    return false;
  }
}

musicControl.addEventListener('click', () => toggleMusic());
playFromCard.addEventListener('click', () => toggleMusic());

async function tryAutoplay() {
  if (!bgm.currentSrc || bgm.networkState === HTMLMediaElement.NETWORK_NO_SOURCE) return;
  try {
    bgm.volume = 0.85;
    await bgm.play();
    musicControl.classList.add('playing');
    musicControl.setAttribute('aria-label', 'Pausar música');
  } catch (error) {
    // fallback on first interaction
  }
}

['click', 'touchstart', 'keydown', 'scroll'].forEach((eventName) => {
  window.addEventListener(eventName, () => {
    if (bgm.paused) {
      tryAutoplay();
    }
  }, { once: true, passive: true });
});

document.addEventListener('DOMContentLoaded', () => {
  tryAutoplay();
});

bgm.addEventListener('play', () => {
  musicControl.classList.add('playing');
});

bgm.addEventListener('pause', () => {
  musicControl.classList.remove('playing');
});

bgm.addEventListener('error', () => {
  musicControl.classList.remove('playing');
});
