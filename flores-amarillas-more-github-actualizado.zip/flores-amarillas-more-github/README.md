# Flores Amarillas para More

Página estática personalizada y preparada para publicar con **GitHub Pages**.

## Publicar en GitHub

1. Crea un repositorio nuevo en GitHub.
2. Sube todos los archivos y carpetas de este proyecto a la raíz del repositorio.
3. En GitHub entra a **Settings → Pages**.
4. En **Build and deployment**, selecciona **Deploy from a branch**.
5. Selecciona la rama `main` y la carpeta `/ (root)`.
6. Guarda. GitHub mostrará la URL pública cuando termine el despliegue.

## Música

El sitio ya tiene el botón preparado. Para utilizar música, coloca un archivo de audio que tengas permiso de usar en:

`audio/mi-cancion.mp3`

No cambies el nombre si quieres que funcione sin editar el código.

## Personalización rápida

- Título y mensajes: `index.html`
- Colores y diseño: `styles.css`
- Animaciones e interacciones: `script.js`
- Fotos: carpeta `fotos/`
- Imagen de Snoopy y recursos visuales: carpeta `img/`


## Actualización personalizada
- Mensajes románticos sobre la distancia.
- Cambio de la imagen de Momento 02.
- Audio incluido en `audio/mi-cancion.mp3` con intento de reproducción automática.
- Mejoras visuales y responsive para móvil.
- Nueva imagen de ramo final optimizada.
